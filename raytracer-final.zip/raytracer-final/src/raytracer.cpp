﻿#include "renderer.h"
#include "raytracer.h"

#ifdef _WIN32
#include "GL/wglew.h"
#endif
#include <GL/gl.h>
#include <GL/freeglut.h>

vector <Sphere> objects;
vector <Light> lights;
Color backgroundColor = Color(0.1, 0.1, 0.1);

using namespace std;
// constructor
Raytracer::Raytracer()
	: m_iWidth(WIDTH)
	, m_iHeight(HEIGHT)
	, m_fHeightAngle(0.4f)
	, m_dNearDistance(1.0)
	, m_dFarDistance(50.0f)
	, m_fRotX(0.0f)
	, m_fRotY(0.0f)
	, m_fTransZ(-10.0f)
{
	srand(time(0));

	// \/\/\/\/\/\/\/	SETTING UP THE SCENE starts here \/\/\/\/\/\/\/\/\/\/\/

	globalCamera.position = Vec3f(0, -1, 5);
	globalCamera.direction = Vec3f(0.0, 0.0, -1.0);
/*
	objects.push_back(Sphere(Vector(0, 0, 0), .5, Material(0.1, 0.9, 0.5, 1, Color(1, 0, 1))));
	objects.push_back(Sphere(Vector(0, -2, 0), .5, Material(0.1, 0.9, 0.5, 1, Color(1,1, 0))));

	Light l;
	l.position = Vector(5.0, -5.0, 4.0);
	l.color = Color(1, 1, 1);
	lights.push_back(l);*/


	float d = 1.25;
	float c = 0.2;
	Vector t = Vector(-2.0, -2.0, 0);
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				objects.push_back(Sphere(Vector(i * d, j * d, k * d) + t, .5, Material(0.3, 0.9, 0.5, 0.8, Color(0.3 + i * c, 0.3  + j * c, 0.8 - k * c))));
			}
		}
	}
	Light l;
	//l.position = Vector(5.0, -5.0, 4.0);
	l.position = Vector(0, 1, 5);
	l.color = Color(1, 1, 1);
	lights.push_back(l);
	float mirror = 0.5;
	objects.push_back(Sphere(Vector(0.0, 1005.0, 0.0), 1000, Material(0.1, 0.3, 0.1, mirror, Color(1.0, 1.0, 0))));
	objects.push_back(Sphere(Vector(0.0, -1005.0, 0.0), 1000, Material(0.1, 0.3, 0.1, mirror, Color(1, 0, 1))));
	objects.push_back(Sphere(Vector(0.0, 0.0, 1005.0), 1000, Material(0.1, 0.3, 0.1, mirror, Color(0, 1, 1.0))));
	objects.push_back(Sphere(Vector(1010.0, 0.0, 0.0), 1000, Material(0.1, 0.3, 0.1, mirror, Color(0.5, 0.7, 0.3))));
	objects.push_back(Sphere(Vector(-1010.0, 0.0, 0.0), 1000, Material(0.1, 0.3, 0.1, mirror, Color(0, 0.7, 0.7))));

	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^ SETTING UP THE SCENE ends here ^^^^^^^^^^^^^^^^^^^^^^^^^^^//
}

Vec3f::Vec3f() {
	v[0] = 0.0;
	v[1] = 0.0;
	v[2] = 0.0;
}

Vec3f::Vec3f(float a, float b, float c) {
	v[0] = a;
	v[1] = b;
	v[2] = c;
}
Vec3f
Vec3f::normalise() {
	float length = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
	v[0] /= length;
	v[1] /= length;
	v[2] /= length;
	return Vec3f(v[0], v[1], v[2]);
}

float
Vec3f::dot(Vec3f a){
	return v[0] * a.v[0] + v[1] * a.v[1] + v[2] * a.v[2];
}

Vec3f
Vec3f::cross(Vec3f a) {
	return Vec3f(v[1] * a.v[2] - v[2] * a.v[1], -(v[0] * a.v[2] - v[2] * a.v[0]), v[0] * a.v[1] - v[1] * a.v[0]);
}

Vec3f 
Vec3f::normal(Vec3f a) {
	Vec3f b = this->cross(a);
	b.normalise();
	return b;
}

float Vec3f::length()
{
	return sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

void
Raytracer::setWindowSize(int iWidth, int iHeight)
{
	m_iWidth = iWidth;
	m_iHeight = iHeight;
	glViewport(0, 0, m_iWidth, m_iHeight);      // tells OpenGL the new size of the render area
}


void
Raytracer::initGL()
{
	//-----------------------------------------------------------------
	// init GL
	//-----------------------------------------------------------------
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushClientAttrib(GL_CLIENT_ALL_ATTRIB_BITS);


	// set background color to black
	glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
	// set depth buffer to far plane
	glClearDepth(1.0f);
	// enable depth test with the z-buffer
	glEnable(GL_DEPTH_TEST);

	// use flat shading (GL_SMOOTH for Gouraud shading)
	glShadeModel(GL_FLAT);

	// fill the front side of the polygone and use wireframe for back side
	glPolygonMode(GL_FRONT, GL_FILL);
	glPolygonMode(GL_BACK, GL_LINE);

	// do not use culling
	glDisable(GL_CULL_FACE);

	// enable anti-aliasing
	glEnable(GL_MULTISAMPLE_ARB);
}


void
Raytracer::uninitGL()
{
	//-----------------------------------------------------------------
	// uninit GL
	//-----------------------------------------------------------------
	glPopClientAttrib();
	glPopAttrib();
}



void
Raytracer::renderCamera()
{
	// render camera
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	double left, right, bottom, top;
	top = m_dNearDistance * std::tan(m_fHeightAngle / 2.0);
	bottom = -top;
	right = top * (double)m_iWidth / (double)m_iHeight;
	left = -right;
	glFrustum((GLdouble)left, (GLdouble)right, (GLdouble)bottom, (GLdouble)top, (GLdouble)m_dNearDistance, (GLdouble)m_dFarDistance);

	// camera placed at (0 0 10) looking in -z direction
	glTranslatef(0, 0, 0);
	glRotatef(m_fRotY, 0.0f, 1.0f, 0.0f);
	glRotatef(m_fRotX, 1.0f, 0.0f, 0.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

Sphere::Sphere(Vector o, GLfloat r, Material m) {
	origin = o;
	radius = r;
	material = m;
}

GLfloat Sphere::intersect(Ray ray)
{
	float t0, t1; // solutions for t if the ray intersects 
				  // geometric solution
	float t;		// final solution
	Vec3f L = origin - ray.origin;
	float tca = L.dot(ray.direction);
	if (tca < 0)
		return PLUSINFINITY;
	float d2 = L.dot(L) - tca * tca;
	if (d2 > radius * radius)
		return PLUSINFINITY;
	float thc = sqrt(radius*radius - d2);
	t0 = tca - thc;
	t1 = tca + thc;
				  // analytic solution
	L = ray.origin - origin;
	float a = ray.direction.dot(ray.direction);
	float b = 2 * ray.direction.dot(L);
	float c = L.dot(L) - radius*radius;

	float discr = b * b - 4 * a * c;
	if (discr < 0)
		return PLUSINFINITY;
	else if (discr == 0) {
		t0 = t1 = -0.5 * b / a;
	}
	else {
		float q = (b > 0) ?
			-0.5 * (b + sqrt(discr)) :
			-0.5 * (b - sqrt(discr));
		t0 = q / a;
		t1 = c / q;
	}
	if (t0 > t1) std::swap(t0, t1);

	if (t0 < 0) {
		t0 = t1; // if t0 is negative, let's use t1 instead 
		if (t0 < 0)
			return PLUSINFINITY; // both t0 and t1 are negative 
	}

	t = t0;

	Vector p = ray.origin + ray.direction * t;

//	printf("kula przecieta w: (%f, %f, %f)\n", p.v[0], p.v[1], p.v[2]);

	return t;
}

Vec3f Sphere::normal(Vector p)
{
	return (p - origin).normalise();
}

float
Raytracer::findClosestIntersection(Ray ray) {

	float min_t = PLUSINFINITY;
	for (int i = 0; i < objects.size(); i++) {

		float t = objects[i].intersect(ray);
		if (t > 0 && min_t > t) {
			min_t = t;
		}
	}
	return min_t;
}

Color Raytracer::shadow(Vector point, int objectID, int lightID, Vector direction) {

	Vector lightPosition = lights[lightID].position;
	Vector toLight = lightPosition - point;
	Vector normal = objects[objectID].normal(point);
	if (normal.dot(toLight) < 0)
		return Color(0, 0, 0);

	float distance = toLight.length();
	toLight = toLight.normalise();
	float t = findClosestIntersection(Ray(point, toLight));

	if (t > 0 && t > distance) {
		Vector normal = objects[objectID].normal(point);
		float dot = normal.dot(toLight);
		Color diffuse = lights[lightID].color * objects[objectID].material.color * dot * objects[objectID].material.diffuse;
		return diffuse;
	}
	return Color(0.0, 0.0, 0.0);
}

Color 
Raytracer::phong(Vector point, int objectID, Vector direction, int lightID) {

	Vector lightPosition = lights[lightID].position;
	Vector toLight = (lights[lightID].position - objects[objectID].origin).normalise();
	Vector normal = objects[objectID].normal(point);
	float distance = toLight.length();
	if (normal.dot(toLight) < 0)
		return Color(0, 0, 0);
	float t = findClosestIntersection(Ray(point, toLight));

	if (t > 0 && t > distance) {
		Vector normal = objects[objectID].normal(point);
		float dot = normal.dot(toLight);
		direction = direction * (-1);
		Vector reflectedRay = normal * 2 * (normal.dot(toLight)) - toLight;
		return lights[lightID].color * objects[objectID].material.specular  * pow(reflectedRay.dot(direction), PHONG_POWER);
	}
	return Color(0.0, 0.0, 0.0);
}

Color Raytracer::castRay(Ray ray, int depth) {

	Material material;
	float min_t = PLUSINFINITY;
	ray.direction = ray.direction.normalise();
	int objectID = -1;
	for (int i = 0; i < objects.size(); i++) {

		float t = objects[i].intersect(ray);
		if (t > 0 && min_t > t) {
			min_t = t;
			material = objects[i].material;
			objectID = i;
		}
	}
	if (min_t == PLUSINFINITY) {

		return backgroundColor;
	}

	Vec3f p = ray.origin + ray.direction * min_t;

	Color c = Color(0,0,0);
	
	if(depth == RECURSIONDEPTH){
		float tmp = objects[objectID].material.ambient;
		c = Color(tmp, tmp, tmp);
	}

	if (depth <= 0)
		return objects[objectID].material.color * (c +  lights[0].color * shadow(p, objectID, 0, ray.direction) * objects[objectID].material.diffuse
		+ lights[0].color * phong(p, objectID, ray.direction, 0) * objects[objectID].material.specular);

	return objects[objectID].material.color * (c + lights[0].color * shadow(p, objectID, 0, ray.direction) * objects[objectID].material.diffuse
		+ lights[0].color * phong(p, objectID, ray.direction, 0) * objects[objectID].material.specular
		+ lights[0].color * reflect(p, ray.direction, objectID, depth - 1) * objects[objectID].material.mirror);
}

Color Raytracer::reflect(Vector point, Vector direction, int objectID, int depth)
{
	Vector normal = objects[objectID].normal(point);
	direction = Vector(-direction.v[0], -direction.v[1], -direction.v[2]);
	direction = direction.normalise();
	Vector reflectedRay = normal * 2 * (normal.dot(direction)) - direction;

	return castRay(Ray(point, reflectedRay), depth);
}

Ray::Ray(Vector o, Vector d) {
	origin = o;
	direction = d;
}

const int width = WIDTH;
const int height = HEIGHT;

bool frame[width][height];
GLfloat framebuffer[width * height * 3];

void
Raytracer::render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glFrontFace(GL_CW);

	for (int i = 0; i < width; i++) {
		for (int j = 0; j < height; j++) {

			float scale = tan(3.14 * (90.0 * 0.5) / 180.0);
			float imageAspectRatio = WIDTH / (float)HEIGHT;

			float x = (2 * (i + 0.5) / (float)width - 1) * imageAspectRatio * scale;
			float y = (1 - 2 * (j + 0.5) / (float)height) * scale; 
					
			Vec3f n = Vector(x + this->globalCamera.direction.v[0], y + this->globalCamera.direction.v[1], +this->globalCamera.direction.v[2]);
			Vec3f camera = this->globalCamera.position;
			Ray ray = Ray(camera, n);

			Color c = castRay(ray, RECURSIONDEPTH);

			framebuffer[3 * (i * width + j)] = c.v[0];
			framebuffer[3 * (i * width + j) + 1] = c.v[1];
			framebuffer[3 * (i * width + j) + 2] = c.v[2];

		}
	}

	glDrawPixels(width, height, GL_RGB, GL_FLOAT, framebuffer);
}

Material::Material(float a, float d, float s, float m, Color c)
{
	color = c;
	specular = s;
	diffuse = d;
	ambient = a;
	mirror = m;
}

Material::Material()
{
	specular = 1.0;
	diffuse = 1.0;
	ambient = 1.0;
	color = Color(0.5, 0.5, 0.5);
}
