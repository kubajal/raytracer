#ifndef RENDERTRIANGLECLASSIC_H
#define RENDERTRIANGLECLASSIC_H

#define MINUSINFINITY -100000.0
#define PLUSINFINITY +100000.0

#include "renderer.h"
#include <GL/glew.h>

#include <iostream>
#include <map>
#include <tuple>
#include <vector>
#include <cmath>
#include <ctime>
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

#define WIDTH 1024					// width of the camera
#define HEIGHT 1024					// height of the camera
#define PHONG_POWER 1000			// power to which the coefficient should be rised computing Phong model of specular light
#define RECURSIONDEPTH 5			// how many times should a ray bounce?

class Vec3f {									// a very basic implementation of 3 dimensional vectors
public:
	float v[3];

	Vec3f();									// sets to (0, 0, 0)
	Vec3f(float x0, float x1, float x2);		// sets to (x0, x1, x2)
	Vec3f normalise();
	float dot(Vec3f x0);						// dot product, this . x0 
	Vec3f cross(Vec3f x0);						// cross product, this x x0
	Vec3f normal(Vec3f x0);						// normal to vector this and x0
	float length();								// length

	string toString() { return "(" + to_string(v[0]) + ", " + to_string(v[1]) + "," + to_string(v[2]) + ")"; } // for debugging

	Vec3f operator -(const Vec3f &x0) const { return Vec3f(v[0] - x0.v[0], v[1] - x0.v[1], v[2] - x0.v[2]); }	// operator overloading for -
	Vec3f operator +(const Vec3f &x0) const { return Vec3f(v[0] + x0.v[0], v[1] + x0.v[1], v[2] + x0.v[2]); }	// operator overloading for +
	Vec3f operator *(const Vec3f &x0) const { return Vec3f(v[0] * x0.v[0], v[1] * x0.v[1], v[2] * x0.v[2]); }	// operator overloading for * _NEITHER DOT NOR CROSS PRODUCT_
	Vec3f operator *(const float &x0) const { return Vec3f(v[0] * x0, v[1] * x0, v[2] * x0); }					// operator overloading for * with a constant
	bool operator !=(const Vec3f &x0) const { return v[0] != x0.v[0] && v[1] != x0.v[1] && v[2] != x0.v[2]; }

};
typedef Vec3f Vector;		// Vector is now alias for Vec3f
typedef Vec3f Color;		// Color is now alias for Vec3f
typedef struct {
	Vector position;
	Color color;
} Light;

typedef struct {
	Vec3f position;
	Vec3f direction;
} Camera;

struct Material {
public:
	float ambient;
	float diffuse;
	float specular;
	float mirror;

	Color color;		// color of the surface
	Material(float a, float d, float s, float m, Color c);
	Material();
};

class Ray {
public:
	Vector origin;
	Vector direction;

	Ray(Vector o, Vector d);
};

class Object {
public:
	Material material;
	virtual GLfloat intersect(Ray r) { return MINUSINFINITY; };		// returns coefficient of the normalised direction vector if it intersects the object
	virtual Vec3f normal(Vector p) { return p; };					// return normal to this and p
};

class Sphere : public Object {
public:
	Sphere(Vector origin, GLfloat r, Material m);
	Vector origin;
	GLfloat radius;

	GLfloat intersect(Ray r);										// overriden from Object, returns coefficient of the normalised direction vector if it intersects the object
	Vec3f normal(Vector p);											// overriden return normal to this and p
};

class Raytracer : public RenderIf
{
public:
	// constructor
	Raytracer();
	// destructor
	virtual ~Raytracer() {};

	// set the size of the window
	virtual void setWindowSize(const int iWidth, const int iHeight);

	// initialize the GL state/scene
	virtual void initGL();
	// free all GL resources
	virtual void uninitGL();

	// update camera parameters and object orientation
	virtual void renderCamera();
	Color shadow(Vector point, int objectID, int lightID, Vector direction);
	float findClosestIntersection(Ray ray);
	Color castRay(Ray ray, int depth);
	Color reflect(Vector point, Vector direction, int objectID, int depth);
	Color phong(Vector p, int oID, Vector direction, int lightID);
	// render the scene
	virtual void render();

	// pass a key to the renderer
	virtual void keyPressed(unsigned char ucKey) {};

	// rotate scene
	virtual void rotX(const float fAngle) { m_fRotX += fAngle; }
	virtual void rotY(const float fAngle) { m_fRotY += fAngle; }
	virtual void transZ(const float fZ) { m_fTransZ *= fZ; }

	Camera globalCamera;
protected:
	int   m_iWidth;
	int   m_iHeight;
	map<pair<int, int>, int> middles_map;

	// vertical viewing angle
	float m_fHeightAngle;

	// near and far distance of scene
	double m_dNearDistance;
	double m_dFarDistance;

	// rotation angle around x-axis
	float  m_fRotX;
	// rotation angle around y-axis
	float  m_fRotY;
	// translation in z-direction
	float  m_fTransZ;

};



#endif